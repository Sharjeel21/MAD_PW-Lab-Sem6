import 'Person.dart';
class personalData{
    List<data> persons=[
           data(
          name:'jayesh',
          time:'10:00 PM',
          amount: '10,000',
           ),
           data(
            name:'jayesh',
            time:'11:00 PM',
            amount:'1000',
           ),
           data(
            name:'jayesh',
            time:'11:30 PM',
            amount:'500'
           ),
           data(
            name:'jayesh',
            time:'11:30 PM',
            amount:'500'
           ),
           data(
            name:'jayesh',
            time:'11:30 PM',
            amount:'500'
           ),
           data(
            name:'jayesh',
            time:'11:30 PM',
            amount:'500'
           ),
           data(
            name:'jayesh',
            time:'11:30 PM',
            amount:'500'
           ),
           data(
            name:'jayesh',
            time:'11:30 PM',
            amount:'500'
           ),
           data(
            name:'jayesh',
            time:'11:30 PM',
            amount:'500'
           ),
           data(
            name:'jayesh',
            time:'11:30 PM',
            amount:'500'
           ),
           data(
            name:'jayesh',
            time:'11:30 PM',
            amount:'500'
           ),
           data(
            name:'jayesh',
            time:'11:30 PM',
            amount:'500'
           ),
           
    ];
}