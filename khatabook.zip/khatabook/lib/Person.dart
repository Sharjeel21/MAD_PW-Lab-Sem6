class data {
    String names = '';
    String times = '';
    String amounts = '';

    data({
        String name = '',
        String time = '',
        String amount = '',

    }) {
        names = name;
        times = time;
        amounts = amount;
    }
}